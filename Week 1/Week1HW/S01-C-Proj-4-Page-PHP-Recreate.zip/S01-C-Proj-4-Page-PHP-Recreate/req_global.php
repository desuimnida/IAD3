<?php

$siteTitle = '4 Page PHP';

?>