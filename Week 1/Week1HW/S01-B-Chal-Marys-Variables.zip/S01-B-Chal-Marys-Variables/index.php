<?php 
$name = 'Lily'; 
$adjective = 'stumpy';
$noun = 'cat';

?>


<!-- Your InitiaLilyed PHP Variables Goes Here -->
<!doctype html>
<html>
	<head>
		<title><?php echo $name = 'Lily'; ?> Had a <?php echo $adjective = 'stumpy'; ?> <?php echo $noun = 'cat'; ?></title>
		<link rel="stylesheet" href="_css/styles.css">
	</head>
	<body>
		<div id="container">
			<header><span class="name"><?php echo $name = 'Lily'; ?></span> Had a <span class="adjective"><?php echo $adjective = 'stumpy'; ?></span> <span class="noun"><?php echo $noun = 'cat'; ?></span></header>
			<article>
				<p>
					<span class="name"><?php echo $name = 'Lily'; ?></span> had a <span class="adjective"><?php echo $adjective = 'stumpy'; ?></span> <span class="noun"><?php echo $noun = 'cat'; ?></span>,<br>
					its fleece was white as snow;<br>
					And everywhere that <span class="name"><?php echo $name = 'Lily'; ?></span> went,<br>
					the <span class="noun"><?php echo $noun = 'cat'; ?></span> was sure to go.
				</p>

				<p>
					It followed her to school one day,<br>
					which was against the rule;<br>
					It made the children laugh and play,<br>
					to see a <span class="noun"><?php echo $noun = 'cat'; ?></span> at school.<br>
					And so the teacher turned it out,<br>
					but still it lingered near,<br>
					And waited patiently about,<br>
					till <span class="name"><?php echo $name = 'Lily'; ?></span> did appear.
				</p>

				<p>
					"Why does the <span class="noun"><?php echo $noun = 'cat'; ?></span> love <span class="name"><?php echo $name = 'Lily'; ?></span> so?"<br>
					the eager children cry;<br>
					"Why, <span class="name"><?php echo $name = 'Lily'; ?></span> loves the <span class="noun"><?php echo $noun = 'cat'; ?></span>, you know",<br>
					the teacher did reply.
				</p>

				<p>
					Alternate Lyrics
					<span class="name"><?php echo $name = 'Lily'; ?></span> had a <span class="adjective"><?php echo $adjective = 'stumpy'; ?></span> <span class="noun"><?php echo $noun = 'cat'; ?></span>,<br>
					<span class="adjective"><?php echo $adjective = 'stumpy'; ?></span> <span class="noun"><?php echo $noun = 'cat'; ?></span>, <span class="adjective"><?php echo $adjective = 'stumpy'; ?></span> <span class="noun"><?php echo $noun = 'cat'; ?></span>,<br>
					<span class="name"><?php echo $name = 'Lily'; ?></span> had a <span class="adjective"><?php echo $adjective = 'stumpy'; ?></span> <span class="noun"><?php echo $noun = 'cat'; ?></span>,<br>
					its fleece was white as snow.
				</p>

				<p>
					And everywhere that <span class="name"><?php echo $name = 'Lily'; ?></span> went,<br>
					<span class="name"><?php echo $name = 'Lily'; ?></span> went, <span class="name"><?php echo $name = 'Lily'; ?></span> went,<br>
					and everywhere that <span class="name"><?php echo $name = 'Lily'; ?></span> went,<br>
					the <span class="noun"><?php echo $noun = 'cat'; ?></span> was sure to go.<br>
				</p>

				<p>
					It followed her to school one day,<br>
					school one day, school one day,<br>
					It followed her to school one day, <br>
					which was against the rules.
				</p>

				<p>
					It made the children laugh and play,<br>
					laugh and play, laugh and play,<br>
					it made the children laugh and play,<br>
					to see a <span class="noun"><?php echo $noun = 'cat'; ?></span> at school.
				</p>

				<p>
					And so the teacher turned it out,<br>
					turned it out, turned it out,<br>
					And so the teacher turned it out,<br>
					but still it lingered near.
				</p>

				<p>
					And waited patiently about,<br>
					patiently about, patiently about,<br>
					And waited patiently about,<br>
					till <span class="name"><?php echo $name = 'Lily'; ?></span> did appear.
				</p>

				<p>
					"Why does the <span class="noun"><?php echo $noun = 'cat'; ?></span> love <span class="name"><?php echo $name = 'Lily'; ?></span> so?"<br>
					Love <span class="name"><?php echo $name = 'Lily'; ?></span> so? Love <span class="name"><?php echo $name = 'Lily'; ?></span> so?<br>
					"Why does the <span class="noun"><?php echo $noun = 'cat'; ?></span> love <span class="name"><?php echo $name = 'Lily'; ?></span> so,"<br>
					the eager children cry.
				</p>

				<p>
					"Why, <span class="name"><?php echo $name = 'Lily'; ?></span> loves the <span class="noun"><?php echo $noun = 'cat'; ?></span>, you know."<br>
					The <span class="noun"><?php echo $noun = 'cat'; ?></span>, you know, the <span class="noun"><?php echo $noun = 'cat'; ?></span>, you know,<br>
					"Why, <span class="name"><?php echo $name = 'Lily'; ?></span> loves the <span class="noun"><?php echo $noun = 'cat'; ?></span>, you know,"<br>
					the teacher did reply.
				</p>
			</article>
		</div>
	</body>
</html>